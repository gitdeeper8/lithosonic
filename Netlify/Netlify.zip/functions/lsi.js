const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // جلب المواقع
    const { data: sites, error: sitesError } = await supabase
      .from('lithosonic_sites')
      .select('*');

    if (sitesError) throw sitesError;

    // جلب آخر قياس لكل موقع
    const { data: params, error: paramsError } = await supabase
      .from('lithosonic_parameters')
      .select('*')
      .order('timestamp', { ascending: false });

    if (paramsError) throw paramsError;

    // إنشاء خريطة لأحدث قياس لكل موقع
    const latestParams = {};
    params.forEach(p => {
      if (!latestParams[p.station_id] || p.timestamp > latestParams[p.station_id].timestamp) {
        latestParams[p.station_id] = p;
      }
    });

    const stations = sites.map(site => {
      const param = latestParams[site.site_id] || {};
      return {
        id: site.site_code,
        name: site.site_name,
        country: site.country,
        env: site.tectonic_environment,
        lat: site.latitude,
        lon: site.longitude,
        lsi: param.lsi_value || 0.5,
        alert: param.lsi_status || 'BACKGROUND',
        b_c: param.b_c_value,
        z_c: param.z_c_value,
        f_n: param.f_n_value,
        alpha_att: param.alpha_att_value,
        s_ae: param.s_ae_value
      };
    });

    const lsiValues = stations.map(s => s.lsi);
    const avgLsi = lsiValues.reduce((a, b) => a + b, 0) / lsiValues.length;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        stations,
        statistics: {
          global_avg_lsi: Number(avgLsi.toFixed(3)),
          global_status: avgLsi >= 0.8 ? 'CRITICAL' : avgLsi >= 0.6 ? 'ELEVATED' : 'BACKGROUND'
        }
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
