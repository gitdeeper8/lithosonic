const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const { data: reports, error: reportsError } = await supabase
      .from('lithosonic_reports')
      .select(`
        *,
        lithosonic_sites!left(site_code, site_name)
      `)
      .order('report_date', { ascending: false })
      .limit(30);

    if (reportsError) throw reportsError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reports })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
