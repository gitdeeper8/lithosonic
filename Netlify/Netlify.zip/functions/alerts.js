const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const { data: active, error: activeError } = await supabase
      .from('lithosonic_alerts')
      .select(`
        *,
        lithosonic_sites!inner(site_code, site_name)
      `)
      .eq('resolved', false)
      .order('alert_timestamp', { ascending: false });

    if (activeError) throw activeError;

    const { data: recent, error: recentError } = await supabase
      .from('lithosonic_alerts')
      .select(`
        *,
        lithosonic_sites!inner(site_code, site_name)
      `)
      .eq('resolved', true)
      .order('alert_timestamp', { ascending: false })
      .limit(10);

    if (recentError) throw recentError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ active, recent })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
