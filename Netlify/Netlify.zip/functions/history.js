const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const stationCode = event.queryStringParameters?.station || 'KILAUEA_ERZ_01';
    const days = parseInt(event.queryStringParameters?.days) || 30;

    const { data: site, error: siteError } = await supabase
      .from('lithosonic_sites')
      .select('site_id')
      .eq('site_code', stationCode)
      .single();

    if (siteError) throw siteError;

    const { data: history, error: historyError } = await supabase
      .from('lithosonic_parameters')
      .select('timestamp, lsi_value, b_c_value, z_c_value, f_n_value, alpha_att_value, s_ae_value')
      .eq('station_id', site.site_id)
      .order('timestamp', { ascending: false })
      .limit(days);

    if (historyError) throw historyError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ station: stationCode, history })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
