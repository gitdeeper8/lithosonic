const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const stationId = event.queryStringParameters?.id || 'KILAUEA_ERZ_01';

    const { data: site, error: siteError } = await supabase
      .from('lithosonic_sites')
      .select('*')
      .eq('site_code', stationId)
      .single();

    if (siteError) throw siteError;

    const { data: params, error: paramsError } = await supabase
      .from('lithosonic_parameters')
      .select('*')
      .eq('station_id', site.site_id)
      .order('timestamp', { ascending: false })
      .limit(30);

    if (paramsError) throw paramsError;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ station: site, measurements: params })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
