const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // استعلام بسيط بدون JOIN
    const { data: measurements, error } = await supabase
      .from('lithosonic_parameters')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(10);

    if (error) throw error;

    // جلب أسماء المواقع بشكل منفصل
    const { data: sites } = await supabase
      .from('lithosonic_sites')
      .select('site_id, site_code, site_name');

    // دمج البيانات يدوياً
    const enhancedMeasurements = measurements.map(m => {
      const site = sites?.find(s => s.site_id === m.station_id) || {};
      return {
        ...m,
        lithosonic_sites: {
          site_code: site.site_code,
          site_name: site.site_name
        }
      };
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        latest_measurements: enhancedMeasurements || []
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
