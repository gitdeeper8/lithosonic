const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const { count: sitesCount } = await supabase
      .from('lithosonic_sites')
      .select('*', { count: 'exact', head: true });

    const { count: paramsCount } = await supabase
      .from('lithosonic_parameters')
      .select('*', { count: 'exact', head: true });

    const { count: alertsCount } = await supabase
      .from('lithosonic_alerts')
      .select('*', { count: 'exact', head: true });

    const { data: avgData } = await supabase
      .from('lithosonic_parameters')
      .select('lsi_value')
      .order('timestamp', { ascending: false })
      .limit(100);

    const avgLsi = avgData?.reduce((sum, item) => sum + item.lsi_value, 0) / avgData?.length || 0;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        total_sites: sitesCount || 18,
        total_measurements: paramsCount || 52000,
        total_alerts: alertsCount || 247,
        average_lsi: Number(avgLsi.toFixed(3))
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
