# 🌍 LITHO-SONIC Netlify Dashboard

**Lithospheric Resonance & Infrasonic Geomechanical Observatory**

[![Netlify Status](https://api.netlify.com/api/v1/badges/lithosonic/deploy-status)](https://lithosonic.netlify.app)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.18931304-4A90D9)](https://doi.org/10.5281/zenodo.18931304)

## 🚀 Live Dashboard
- **Dashboard:** https://lithosonic.netlify.app
- **API:** https://lithosonic.netlify.app/api
- **Docs:** https://lithosonic.netlify.app/docs

## 📡 API Endpoints
| Endpoint | Description |
|----------|-------------|
| `/api/lsi` | Current LSI values for all stations |
| `/api/station/:id` | Station-specific data |
| `/api/parameters` | Five parameters data |
| `/api/alerts` | Active geophysical alerts |
| `/api/stats` | System statistics |
| `/api/history` | Historical LSI data |
| `/api/reports` | Daily reports |

## 🔧 Local Development
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Install dependencies
npm install

# Start local server
netlify dev
```

📖 Citation

```bibtex
@software{baladi2026lithosonic,
  author = {Baladi, Samir},
  title = {LITHO-SONIC: Lithospheric Resonance Observatory},
  year = {2026},
  doi = {10.5281/zenodo.18931304}
}
```

